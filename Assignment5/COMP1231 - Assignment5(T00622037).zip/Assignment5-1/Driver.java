//*******************************************************************
// Driver.java            
//
// Anton Nikitenko T00622037
// COMP 1231 Assignment 5 Part 1
// Program which allows the user to input text with a GUI application, 
// then analyzes the number of words, and outputs the total number of 
// words, as well as average word count of the user's input, in the 
// GUI application as well
//*******************************************************************

public class Driver {
	public static void main(String[] args)
	{
		// Declare and initialize the GUI TextAnalyser class for the application
		TextAnalyser app = new TextAnalyser();
	}
}
